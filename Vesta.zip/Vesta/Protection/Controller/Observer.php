<?php

namespace Vesta\Protection\Controller;

use Magento\Framework\Event\ObserverInterface;

class Observer implements ObserverInterface {

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
    protected $_storeManager;
    protected $scopeConfig;
    public $messageManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(\Magento\Framework\ObjectManagerInterface $objectManager, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Framework\Message\ManagerInterface $messageManager) {

        $this->_objectManager = $objectManager;
        $this->_storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->messageManager = $messageManager;
    }

    /**
     * customer register event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        return $this->sendRequestToprotection($observer);
    }

    public function sendRequestToprotection($observer) {
        $event = $observer->getEvent();
        $order = $event->getOrder();

        if ($order->getprotection_response()) {
            return true;
        }
        return $this->processSendRequestToprotection($order);
    }

    public function sendRequestToprotectionNonObserver($observer) {
        if (!$this->scopeConfig->getValue('protection/active_display/active', \Magento\Store\Model\ScopeInterface::SCOPE_STORE)) {
            return true;
        }

        $event = $observer->getEvent();
        $order = $event->getOrder();

        if ($order->getprotection_response()) {
            $this->messageManager->addError(__('Request already submitted to Vesta Protection.'));
            return true;
        }

        return $this->processSendRequestToprotection($order);
    }

    public function processSendRequestToprotection($order) {
        $orderId = $order->getIncrementId();

        if (empty($orderId))
            return true;

        $data = unserialize($order->getprotection_response());

        if ($data)
            return true;

        if (isset($_SERVER['DEV_MODE']))
            $_SERVER['REMOTE_ADDR'] = '175.143.8.154';

        $apiKey = $this->scopeConfig->getValue('protection/active_display/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $reviewStatus = $this->scopeConfig->getValue('protection/active_display/review_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $rejectStatus = $this->scopeConfig->getValue('protection/active_display/reject_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        $billingAddress = $order->getBillingAddress();
        $ip = $_SERVER['REMOTE_ADDR'];

        if (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && filter_var($_SERVER['HTTP_CF_CONNECTING_IP'], FILTER_VALIDATE_IP)) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }

        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $xip = trim(current(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])));

            if (filter_var($xip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                $ip = $xip;
            }
        }

        $payment_mode = $order->getPayment()->getMethod();
        if($payment_mode === 'ccsave'){
            $paymentMode = 'creditcard';
        }elseif($payment_mode === 'cashondelivery'){
            $paymentMode = 'cod';
        }elseif($payment_mode === 'paypal_standard' || $payment_mode === 'paypal_express'){
            $paymentMode = 'paypal';
        }else{
            $paymentMode = $payment_mode;
        }

        $queries = array(
            'format' => 'json',
            'key' => $apiKey,
            'ip' => $ip,
            'first_name' => $billingAddress->getFirstname(),
            'last_name' => $billingAddress->getLastname(),
            'bill_addr' => implode(" ", $billingAddress->getStreet()),
            'bill_city' => $billingAddress->getCity(),
            'bill_state' => $billingAddress->getRegion(),
            'bill_country' => $billingAddress->getCountryId(),
            'bill_zip_code' => $billingAddress->getPostcode(),
            'email_domain' => substr($order->getCustomerEmail(), strpos($order->getCustomerEmail(), '@') + 1),
            'email_hash' => $this->_hash($order->getCustomerEmail()),
            'email' => $order->getCustomerEmail(),
            'user_phone' => $billingAddress->getTelephone(),
            'amount' => $order->getBaseGrandTotal(),
            'quantity' => count($order->getAllItems()),
            'currency' => $this->_storeManager->getStore()->getCurrentCurrencyCode(),
            'user_order_id' => $orderId,
            'magento_order_id' => $order->getEntityId(),
            'payment_mode' => $paymentMode,
            'flp_checksum' => ( isset( $_COOKIE['flp_checksum'] ) ) ? $_COOKIE['flp_checksum'] : '',
            'source' => 'magento',
            'source_version' => '2.0.11',
        );

        $shippingAddress = $order->getShippingAddress();

        if($shippingAddress){
            $queries['ship_first_name'] = $shippingAddress->getFirstname();
            $queries['ship_last_name'] = $shippingAddress->getLastname();
            $queries['ship_addr'] = implode(" ", $shippingAddress->getStreet());
            $queries['ship_city'] = $shippingAddress->getCity();
            $queries['ship_state'] = $shippingAddress->getRegion();
            $queries['ship_zip_code'] = $shippingAddress->getPostcode();
            $queries['ship_country'] = $shippingAddress->getCountryId();
        }

        $response = $this->http('https://api.protection.com/v1/order/screen?' . http_build_query($queries));
echo $response;
        if (is_null($result = json_decode($response, true)) === TRUE)
            return false;

        $result['ip_address'] = $queries['ip'];
        $result['api_key'] = $apiKey;

        $order->setprotection_response(serialize($result))->save();

        if ($result['protection_status'] == 'REVIEW') {

            switch ($reviewStatus) {
                case 'pending':
                    $order->setState(\Magento\Sales\Model\Order::STATE_NEW, true)->save();
                    $order->setStatus('pending', true)->save();
                    break;

                case 'processing':
                    $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
                    break;

                case 'complete':
                    $order->setState(\Magento\Sales\Model\Order::STATE_COMPLETE, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_COMPLETE, true)->save();
                    break;

                case 'closed':
                    $order->setState(\Magento\Sales\Model\Order::STATE_CLOSED, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_CLOSED, true)->save();
                    break;

                case 'fraud':
                    $order->setState(\Magento\Sales\Model\Order::STATUS_FRAUD, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATUS_FRAUD, true)->save();
                    break;

                case 'canceled':
                    if ($order->canCancel()) {
                        $order->cancel()->save();
                    }
                    break;

                case 'holded':
                    $order->setHoldBeforeState($order->getState());
                    $order->setHoldBeforeStatus($order->getStatus());
                    $order->setState(\Magento\Sales\Model\Order::STATE_HOLDED, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_HOLDED, true)->save();
                    break;
            }
        }

        if ($result['protection_status'] == 'REJECT') {

            switch ($rejectStatus) {
                case 'pending':
                    $order->setState(\Magento\Sales\Model\Order::STATE_NEW, true)->save();
                    $order->setStatus('pending', true)->save();
                    break;

                case 'processing':
                    $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
                    break;

                case 'complete':
                    $order->setState(\Magento\Sales\Model\Order::STATE_COMPLETE, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_COMPLETE, true)->save();
                    break;

                case 'closed':
                    $order->setState(\Magento\Sales\Model\Order::STATE_CLOSED, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_CLOSED, true)->save();
                    break;

                case 'fraud':
                    $order->setState(\Magento\Sales\Model\Order::STATUS_FRAUD, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATUS_FRAUD, true)->save();
                    break;

                case 'canceled':
                    if ($order->canCancel()) {
                        $order->cancel()->save();
                    }
                    break;

                case 'holded':
                    $order->setHoldBeforeState($order->getState());
                    $order->setHoldBeforeStatus($order->getStatus());
                    $order->setState(\Magento\Sales\Model\Order::STATE_HOLDED, true)->save();
                    $order->setStatus(\Magento\Sales\Model\Order::STATE_HOLDED, true)->save();
                    break;
            }
        }
        $this->messageManager->addSuccess(__('Vesta Protection Request sent.'));
        return true;
    }

    private function http($url) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $result = curl_exec($ch);

        if (!curl_errno($ch))
            return $result;

        curl_close($ch);

        return false;
    }

    private function _hash($s, $prefix = 'protection_') {
        $hash = $prefix . $s;
        for ($i = 0; $i < 65536; $i++)
            $hash = sha1($prefix . $hash);
        return $hash;
    }

}
