<?php

namespace Vesta\Protection\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action {

    public function execute() {
        /* Paste your code here */
    }

}
