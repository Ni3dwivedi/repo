<?php

namespace Vesta\Protection\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /* Paste your code here */
}