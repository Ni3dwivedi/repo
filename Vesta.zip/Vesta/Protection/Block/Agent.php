<?php
namespace Vesta\Protection\Block;
class Agent extends \Magento\Backend\Block\Template
{
    public function isActive()
    {
        return true;
    }
}


